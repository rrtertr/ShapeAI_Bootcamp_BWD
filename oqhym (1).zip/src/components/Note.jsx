import React from "react"

function Note(){
  return(
    <div className="note">
      <h1>Javascript and React.js</h1>
      <p>this was an amazing bootcamp taken by Shaurya Sinha.We
        covered everything from scratch including Javascript and
        React.js,HTML.React.js is simple , intuitve,usable and 
        stand out.
        </p>)
        </div>
  );
}
export default Note; 